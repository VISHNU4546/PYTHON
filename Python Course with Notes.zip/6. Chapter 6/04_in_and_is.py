# a = None
# if (a is None):
#     print("Yes")
# else:
#     print("No")

a = [45, 56, 6]
print(435 in a)