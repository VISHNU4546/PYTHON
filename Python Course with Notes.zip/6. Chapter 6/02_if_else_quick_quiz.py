age = int(input("Enter your age: "))

if age>18:
    print("Yes")
else:
    print("No")