age = int(input("Enter your age: "))
if(age>34 or age<56):
    print("You can work with us")

else:
    print("You cannot work with us")