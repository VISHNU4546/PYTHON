name = input("Enter your name\n")
print("Good Afternoon, " + name)