letter = "Dear Harry, This Python course is nice! Thanks!"
print(letter)

formatted_letter = "Dear Harry,\n\tThis Python course is nice!\nThanks!"
print(formatted_letter)