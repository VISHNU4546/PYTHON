a = {1, 3, 4, 5, 1}
print(type(a))
print(a)